cli to upload file /folder

usage:-

mtup "FILE_NAME" 
mtup "FOLDER_NAME"
