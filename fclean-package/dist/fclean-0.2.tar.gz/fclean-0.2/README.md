Flutter clean architecture cli helper

bloc/cubit for business logic
equatable for comparision
dio for network call 