cross platform notification cli 
tested on windows 10 
linux -- requires libnotify-bin, install by "sudo apt-get install libnotify-bin"
mac os

usage

dnotify "$title" "$description"

use "dnotify -h" for more info
