ez flutter builder cli  
for more info
ezfba -h
