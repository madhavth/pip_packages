shell script creator helper
