# setup.py
from setuptools import setup

setup(
    name='wpass',
    scripts=['wpass'],
	version= '0.1',
	description = 'cli tool to find wifi passwords',
	author = 'madhavth'
)
